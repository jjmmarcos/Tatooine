<?php

namespace App\Http\Livewire\Admin;

use Livewire\Component;

class AminCouponsComponent extends Component
{
    public function render()
    {
        return view('livewire.admin.amin-coupons-component');
    }
}
